#include <iostream>
#include <vector>
#include <iomanip>
#include <limits>
using namespace std;

struct FoodItem {
    string name;
    double calories;
    double carbohydrates;
    double sugar;
    double fiber;      // FIXED: changed from "fibre" to "fiber"
    double protein;
    double fat;
    double water;
    double grams;
};

vector<FoodItem> history;
string currentUser = "";

bool login();
void showMainMenu();
void historyLog();
void foodInput();
void netCalculator();
void exitApp();
void displayFoodItem(const FoodItem& item);
void showHealthAdvice(double totalCalories, double totalSugar, double totalFat);

int main() {
    if (login()) {
        showMainMenu();
    }

    return 0;
}

bool login() {
    string username, password;
    int attempts = 0;
    const int maxAttempts = 3;

    cout << "=== FOOD TRACKING APP ===\n";
    cout << "Username: ";
    cin >> username;

    while (attempts < maxAttempts) {
        cout << "Password: ";
        cin >> password;

        if (password == "password123") {
            currentUser = username;
            cout << "Welcome, " << currentUser << "!\n";
            return true;
        } else {
            attempts++;
            cout << "Incorrect password! ";
            if (attempts < maxAttempts) {
                cout << "You have " << (maxAttempts - attempts) << " attempt(s) remaining.\n";
            } else {
                cout << "Maximum attempts reached. Access denied.\n";
                return false;
            }
        }
    }

    return false;
}

void showMainMenu() {
    int choice;

    do {
        cout << "\n=== MAIN MENU ===\n";
        cout << "1. Input Food\n";
        cout << "2. View History\n";
        cout << "3. Net Calculator\n";
        cout << "4. Exit\n";
        cout << "Enter your choice (1-4): ";
        cin >> choice;

        switch(choice) {
            case 1:
                foodInput();
                break;
            case 2:
                historyLog();
                break;
            case 3:
                netCalculator();
                break;
            case 4:
                exitApp();
                break;
            default:
                cout << "Invalid choice! Please try again.\n";
        }
    } while (choice != 4);
}

void foodInput() {
    FoodItem newFood;

    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    cout << "\n=== INPUT FOOD ===\n";
    cout << "Enter food name: ";
    getline(cin, newFood.name);

    cout << "\nEnter nutritional values per 100 grams:\n";
    cout << "Calories (kcal): ";
    cin >> newFood.calories;
    cout << "Carbohydrates (g): ";
    cin >> newFood.carbohydrates;
    cout << "Sugar (g): ";
    cin >> newFood.sugar;
    cout << "Fiber (g): ";
    cin >> newFood.fiber;
    cout << "Protein (g): ";
    cin >> newFood.protein;
    cout << "Fat (g): ";
    cin >> newFood.fat;
    cout << "Water (g): ";
    cin >> newFood.water;

    cout << "\nEnter how many grams you consumed: ";
    cin >> newFood.grams;

    double multiplier = newFood.grams / 100.0;

    FoodItem consumedFood;
    consumedFood.name = newFood.name;
    consumedFood.grams = newFood.grams;
    consumedFood.calories = newFood.calories * multiplier;
    consumedFood.carbohydrates = newFood.carbohydrates * multiplier;
    consumedFood.sugar = newFood.sugar * multiplier;
    consumedFood.fiber = newFood.fiber * multiplier;
    consumedFood.protein = newFood.protein * multiplier;
    consumedFood.fat = newFood.fat * multiplier;
    consumedFood.water = newFood.water * multiplier;

    history.push_back(consumedFood);

    cout << "\nFood item added to history!\n";
    cout << "Calculated values for " << consumedFood.grams << " grams of " << consumedFood.name << ":\n";
    displayFoodItem(consumedFood);
}

void displayFoodItem(const FoodItem& item) {
    cout << fixed << setprecision(2);
    cout << "Food: " << item.name << " (" << item.grams << "g)\n";
    cout << "Calories: " << item.calories << " kcal\n";
    cout << "Carbohydrates: " << item.carbohydrates << " g\n";
    cout << "Sugar: " << item.sugar << " g\n";
    cout << "Fiber: " << item.fiber << " g\n";
    cout << "Protein: " << item.protein << " g\n";
    cout << "Fat: " << item.fat << " g\n";
    cout << "Water: " << item.water << " g\n";
    cout << "----------------------------------------\n";
}

void historyLog() {
    cout << "\n=== FOOD HISTORY ===\n";

    if (history.empty()) {
        cout << "No food items in history.\n";
        return;
    }

    for (size_t i = 0; i < history.size(); i++) {
        cout << "Item #" << (i + 1) << ":\n";
        displayFoodItem(history[i]);
    }
}

void showHealthAdvice(double totalCalories, double totalSugar, double totalFat) {
    cout << "\n=== HEALTH ADVISORY ===\n";

    if (totalCalories > 4000) {
        cout << "WARNING: Very high calorie intake (" << totalCalories << " kcal).\n";
    }

    if (totalSugar > 50) {
        cout << "High sugar intake detected (" << totalSugar << "g).\n";
    }

    if (totalFat > 70) {
        cout << "High fat intake detected (" << totalFat << "g).\n";
    }

    if (totalCalories <= 4000 && totalSugar <= 50 && totalFat <= 70) {
        cout << "Your nutritional intake appears to be within reasonable ranges.\n";
    }
}

void netCalculator() {
    cout << "\n=== NET CALCULATOR ===\n";

    if (history.empty()) {
        cout << "No food items to calculate.\n";
        return;
    }

    double totalCalories = 0, totalCarbs = 0, totalSugar = 0;
    double totalFiber = 0, totalProtein = 0, totalFat = 0, totalWater = 0;
    double totalGrams = 0;

    for (const auto& item : history) {
        totalCalories += item.calories;
        totalCarbs += item.carbohydrates;
        totalSugar += item.sugar;
        totalFiber += item.fiber;
        totalProtein += item.protein;
        totalFat += item.fat;
        totalWater += item.water;
        totalGrams += item.grams;
    }

    cout << fixed << setprecision(2);
    cout << "TOTAL INTAKE (" << history.size() << " items):\n";
    cout << "Total Food Consumed: " << totalGrams << " g\n";
    cout << "Total Calories: " << totalCalories << " kcal\n";
    cout << "Total Carbohydrates: " << totalCarbs << " g\n";
    cout << "Total Sugar: " << totalSugar << " g\n";
    cout << "Total Fiber: " << totalFiber << " g\n";
    cout << "Total Protein: " << totalProtein << " g\n";
    cout << "Total Fat: " << totalFat << " g\n";
    cout << "Total Water: " << totalWater << " g\n";

    showHealthAdvice(totalCalories, totalSugar, totalFat);
}

void exitApp() {
    cout << "\nThank you for using the Food Tracking App!\n";
    cout << "Goodbye, " << currentUser << "!\n";
}
